#' Print information on the content of the pwreg.score object
#' @description Print information on the content of the pwreg.score object
#' @param x A object of class pwreg.score.
#' @param ... further arguments passed to or from other methods.
#' @return Print the results of \code{pwreg.score} object.
#' @seealso \code{\link{score.proc}}
#' @export
#' @keywords pwreg
#' @examples
#' # see the example for score.proc
print.pwreg.score <- function(x, ...) {
  cat("This object contains two components:\n")
  cat(" 't': an l-vector of times\n")
  cat(
    " 'score': a p-by-l matrix whose k'th row is the standardized score process for the k'th covariate
          as a function of t\n\n"
  )
  cat("Use 'plot(object,k=k)' to plot the k'th score process.\n")
}
