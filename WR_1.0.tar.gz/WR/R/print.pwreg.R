#' Print the results of the proportional win-fractions regression model
#' @description Print the results of the proportional win-fractions regression model.
#' @param x an object of class \code{pwreg}.
#' @param digits number of significant digits to display (default is 3).
#' @param ... further arguments passed to or from other methods
#' @return Print the results of \code{pwreg} object
#' @seealso \code{\link{pwreg}}
#' @export
#' @keywords pwreg
#' @examples
#' # see the example for pwreg
print.pwreg <- function(x, digits = 3, ...) {
  cat("Call:\n")
  print(x$call)
  cat("\n")
  strata <- x$strata
  beta <- x$beta
  var <- x$Var
  t <- x$t
  # Coerce to numeric to avoid integer overflow for very large n (e.g., > 1e6)
  n <- as.numeric(x$n)
  comp <- x$comp
  varnames <- x$varnames
  se <- sqrt(diag(var))
  pv <- 2 * (1 - pnorm(abs(beta / se)))
  fmt_num <- function(v) formatC(v, digits = digits, format = "fg")

  if (is.null(strata)) {
    cat(
      "Proportional win-fractions regression models for priority-adjusted composite endpoint\n
    (Mao and Wang, 2020):\n\n"
    )
    # compute total pairs in double precision to avoid integer overflow
    tn <- as.numeric(n) * (as.numeric(n) - 1) / 2
    cat("Total number of pairs:", format(tn, scientific = FALSE), "\n")
    w1 <- sum(comp == 1)
    p1 <- 100 * w1 / tn
    w2 <- sum(comp == 2)
    p2 <- 100 * w2 / tn
    w0 <- sum(comp == 0)
    p0 <- 100 * w0 / tn
    cat("Wins-losses on death: ", paste0(w1, " (", fmt_num(p1), "%)"), "\n")
    cat(
      "Wins-losses on non-fatal event: ",
      paste0(w2, " (", fmt_num(p2), "%)"),
      "\n"
    )
    cat("Indeterminate pairs ", paste0(w0, " (", fmt_num(p0), "%)"), "\n\n")
  } else {
    cat(
      "Stratified proportional win-fractions regression analysis\n
    (Wang and Mao, 2021+):\n\n"
    )
    cat("Total number of strata:", length(levels(strata)), "\n")
  }

  cat("Newton-Raphson algorithm converged in", x$i, "iterations.\n\n")
  Stat <- t(beta) %*% solve(var) %*% beta
  pval <- 1 - pchisq(Stat, length(beta))
  cat(
    "Overall test: chisq test with",
    length(beta),
    "degrees of freedom;",
    "\n",
    "Wald statistic",
    fmt_num(as.numeric(Stat)),
    "with p-value",
    format.pval(pval, digits = digits),
    "\n\n"
  )

  table <- cbind(
    Estimate = beta,
    StdErr = se,
    z.value = beta / se,
    p.value = pv
  )

  colnames(table) <- c("Estimate", "se", "z.value", "p.value")
  rownames(table) <- varnames

  cat("Estimates for Regression parameters:\n")
  printCoefmat(table, digits = digits, P.values = TRUE, has.Pvalue = TRUE)
  cat("\n")
  cat("\n")

  za <- qnorm(0.975)
  MR <- cbind(exp(beta), exp(beta - za * se), exp(beta + za * se))
  colnames(MR) <- c("Win Ratio", "95% lower CL", "95% higher CL")
  rownames(MR) <- varnames
  cat("Point and interval estimates for the win ratios:\n")
  print(MR, digits = digits, quote = FALSE)
  cat("\n")
}
