#' Plot the standardized score processes
#' @description Plot the standardized score processes.
#' @param x an object of class \code{pwreg.score}.
#' @param k A positive integer indicating the order of covariate to be plotted.
#'    For example, \code{k=3} requests the standardized score process for the third covariate in the covariate matrix \code{Z}.
#' @param xlab a title for the x axis.
#' @param ylab a title for the y axis.
#' @param lty the line type. Default is 1.
#' @param frame.plot a logical variable indicating if a frame should be drawn in the 1D case.
#' @param add a logical variable indicating whether add to current plot?
#' @param ylim a vector indicating the range of y-axis. Default is (-3,3).
#' @param xlim a vector indicating the range of x-axis. Default is NULL.
#' @param lwd the line width, a positive number. Default is 1.
#' @param ... further arguments passed to or from other methods
#' @return A plot of the standardized score process for object \code{pwreg.score}.
#' @seealso \code{\link{score.proc}}
#' @export
#' @importFrom graphics lines plot
#' @keywords pwreg
#' @examples
#' # see the example for score.proc
plot.pwreg.score <- function(
  x,
  k,
  xlab = "Time",
  ylab = "Standardized score",
  lty = 1,
  frame.plot = TRUE,
  add = FALSE,
  ylim = c(-3, 3),
  xlim = NULL,
  lwd = 1,
  ...
) {
  score <- x$score
  scorek <- score[k, ]
  t <- x$t
  if (is.null(xlim)) {
    xlim <- c(0, max(t))
  }

  if (add == FALSE) {
    plot(
      t,
      scorek,
      type = "l",
      lty = lty,
      xlab = xlab,
      ylab = ylab,
      ylim = ylim,
      xlim = xlim,
      lwd = lwd,
      frame.plot = frame.plot,
      main = rownames(score)[k],
      ...
    )
  } else {
    lines(t, scorek, lty = lty, ...)
  }
}
