#' Print the results of the two-sample recurrent-event win ratio analysis
#' @description Print the results of the two-sample recurrent-event win ratio analysis.
#' @param x an object of class \code{WRrec}.
#' @param digits number of significant digits to display (default is 3).
#' @param ... further arguments passed to or from other methods.
#' @return Print the results of \code{WRrec} object.
#' @seealso \code{\link{WRrec}}
#' @export
#' @keywords WRrec
#' @examples
#' # see the example for WRrec
print.WRrec <- function(x, digits = 3, ...) {
  cat("Call:\n")
  print(x$call)
  cat("\n")
  print(x$desc)
  n0 <- as.numeric(x$desc[1, 1])
  n1 <- as.numeric(x$desc[2, 1])
  N <- as.numeric(n0) * as.numeric(n1)

  tab <- matrix(NA, 1, 4)
  colnames(tab) <- c("Win prob", "Loss prob", "WR (95% CI)*", "p-value")
  rownames(tab) <- "LWR"
  za <- qnorm(0.975)
  beta <- x$log.WR
  se <- x$se
  theta <- x$theta

  .fmt_num <- function(v) formatC(v, digits = digits, format = "fg")

  tab[1, ] <- c(
    paste0(.fmt_num(100 * theta[1]), "%"),
    paste0(.fmt_num(100 * theta[2]), "%"),
    paste0(
      .fmt_num(exp(beta)),
      " (",
      .fmt_num(exp(beta - za * se)),
      ", ",
      .fmt_num(exp(beta + za * se)),
      ")"
    ),
    format.pval(1 - pchisq((beta / se)^2, 1), digits = digits)
  )

  cat("\n")

  nf <- !is.null(x$log.WR.naive)

  if (!nf) {
    cat("Analysis of last-event-assisted WR (LWR):\n")
  } else {
    cat(
      "Analysis of last-event-assisted WR (LWR; recommended), first-event-assisted WR (FWR), and naive WR (NWR):\n"
    )
  }

  if (!is.null(x$log.WR.naive)) {
    beta.naive <- x$log.WR.naive
    se.naive <- x$se.naive
    theta.naive <- x$theta.naive

    beta.FI <- x$log.WR.FI
    se.FI <- x$se.FI
    theta.FI <- x$theta.FI

    tab <- rbind(
      tab,
      c(
        paste0(.fmt_num(100 * theta.FI[1]), "%"),
        paste0(.fmt_num(100 * theta.FI[2]), "%"),
        paste0(
          .fmt_num(exp(beta.FI)),
          " (",
          .fmt_num(exp(beta.FI - za * se.FI)),
          ", ",
          .fmt_num(exp(beta.FI + za * se.FI)),
          ")"
        ),
        format.pval(1 - pchisq((beta.FI / se.FI)^2, 1), digits = digits)
      ),
      c(
        paste0(.fmt_num(100 * theta.naive[1]), "%"),
        paste0(.fmt_num(100 * theta.naive[2]), "%"),
        paste0(
          .fmt_num(exp(beta.naive)),
          " (",
          .fmt_num(exp(beta.naive - za * se.naive)),
          ", ",
          .fmt_num(exp(beta.naive + za * se.naive)),
          ")"
        ),
        format.pval(1 - pchisq((beta.naive / se.naive)^2, 1), digits = digits)
      )
    )
    rownames(tab)[2:3] <- c("FWR", "NWR")
  }

  print(tab, quote = F)
  cat("-----\n")
  cat(
    "Total number of pairs: ",
    gsub("(?<=\\d)(?=(\\d{3})+$)", ",", as.numeric(x$nb.pairs), perl = TRUE),
    "\n"
  )

  cat("\n")
  cat(
    "*Note: The scale of WR should be interpreted with caution as it depends on \n"
  )
  cat("censoring distribution without modeling assumptions.\n")
}
