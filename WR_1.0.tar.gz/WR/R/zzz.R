#' @useDynLib WR, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
