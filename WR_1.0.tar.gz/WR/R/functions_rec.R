#' Reorganize recurrent-event data by treatment arm
#'
#' @description
#' Sorts longitudinal patient records by ID and time, then splits them into two
#' arm-specific lists (trt = 1 and trt = 0). Within each arm, each patient is
#' represented by a list containing a scalar ID, a vector of ordered observation
#' times, and the patient's final (last observed) status code.
#'
#' @param ID Vector of patient identifiers (integer, numeric, or character). All elements
#' corresponding to the same patient must be identical.
#' @param time Numeric vector of observation/event times. Must be non-decreasing within patient
#' after sorting; ties are allowed but will be preserved as given after sorting.
#' @param status Integer or numeric vector of status codes per observation. The function retains
#' only the last observed status per patient in the output.
#' @param trt Integer or logical treatment indicator with values 1 (treated) and 0 (control).
#' Values are coerced via `trt == 1L` to define the treated arm.
#'
#' @return
#' A named list with two elements:
#' - `dat1`: a list of patients in the treated arm (`trt == 1L`),
#' - `dat0`: a list of patients in the control arm (`trt == 0L`).
#'
#' Each element (`dat1`/`dat0`) is a named list where names correspond to patient IDs.
#' Each patient entry is itself a list with components:
#' - `ID`: scalar patient ID,
#' - `time`: numeric vector of ordered observation times for that patient,
#' - `status`: scalar final status (last observed status for that patient).
#' @export
#' @importFrom stats median
#' @importFrom utils head
#'
process.dat <- function(ID, time, status, trt) {
  o <- order(ID, time)
  ID <- ID[o]
  time <- time[o]
  status <- status[o]
  trt <- trt[o]

  make_arm_rle <- function(IDa, timea, statusa) {
    if (!length(IDa)) {
      return(list())
    }
    r <- rle(IDa) # runs are patients
    n <- length(r$lengths)
    starts <- c(1L, 1L + cumsum(r$lengths)[-n])
    ends <- cumsum(r$lengths)

    out <- vector("list", n)
    for (k in seq_len(n)) {
      i <- starts[k]
      j <- ends[k]
      out[[k]] <- list(ID = IDa[i], time = timea[i:j], status = statusa[j])
    }
    out
  }

  trt1 <- (trt == 1L)

  list(
    dat1 = make_arm_rle(ID[trt1], time[trt1], status[trt1]),
    dat0 = make_arm_rle(ID[!trt1], time[!trt1], status[!trt1])
  )
}


#' Win Ratio for Recurrent Events
#'
#' @description
#' Perform stratified two-sample test of possibly recurrent nonfatal
#' event and death. A total of three win ratio variants are implemented:
#' the last-event assisted win ratio (LWR, the default), the naive win ratio (NWR), and the
#' first-event assisted win ratio (FWR) (Mao et al., 2022). The LWR is the primary method
#' recommended for use (Mao et al., 2022). The LWR and FWR reduce to the standard win ratio
#' of Pocock et al. (2012).
#'
#' The method also supports stratification: comparisons are performed within each stratum and then
#' combined to produce an overall estimate.
#'
#' @param ID Vector (integer, character, or factor). Corresponds to the subjects identification.
#'   Repeated values indicate multiple recurrent event records for the same subject.
#' @param time Numeric vector. Contains event or censoring times aligned with \code{ID}.
#'   Must be non‑negative; assumed already on the analysis time scale.
#' @param status Numeric vector. Contains event indicators aligned with \code{ID}. Valid values are:
#'   \code{0} (censoring), \code{1} (terminal event), and \code{2} (recurrent event).
#'   Each subject can have at most one final status of \code{0} or \code{1}.
#' @param trt Numeric vector. Contains the treatment group indicator aligned with \code{ID}. Valid
#'   values are binary (0/1) or a factor with exactly two levels.
#' @param strata (Optional) Numeric vector. If supplied, comparisons are restricted to
#'   individuals with the same stratum value, aligned with \code{ID}. Default is \code{NULL} (unstratified).
#' @param naive Logical. If \code{TRUE}, computes "FWR" and "NWR" in addition to "LWR". Default
#'   is \code{FALSE} (only "LWR" is computed).
#'
#' @return A list with the following components:
#'
#' \describe{
#'   \item{\code{log.WR}}{Estimated log LWR.}
#'   \item{\code{se}}{Standard error of \code{log.WR}.}
#'   \item{\code{pval}}{Two‑sided p‑value testing H0: LWR = 1.}
#'   \item{\code{theta}}{Wins and losses proportions, respectively, for LWR.}
#'   \item{\code{desc}}{Data frame summarizing, for each treatment arm, the number of subjects,
#'     number of recurrent events, number of deaths, and median follow-up time.}
#'   \item{\code{nb.pairs}}{Total number of pairs.}
#' }
#'
#' If \code{naive = TRUE}, the list also contains:
#'
#' \describe{
#'   \item{\code{log.WR.naive}}{Estimated log NWR.}
#'   \item{\code{se.naive}}{Standard error of \code{log.WR.naive}.}
#'   \item{\code{theta.naive}}{Wins and losses proportions, respectively, for NWR.}
#'   \item{\code{pval.naive}}{Two‑sided p‑value testing H0: NWR = 1.}
#'   \item{\code{log.WR.FI}}{Estimated log FWR.}
#'   \item{\code{se.FI}}{Standard error of \code{log.WR.FI}.}
#'   \item{\code{theta.FI}}{Wins and losses proportions, respectively, for FWR.}
#'   \item{\code{pval.FI}}{Two‑sided p‑value testing H0: FWR = 1.}
#' }
#'
#' @references Mao, L., Kim, K. and Li, Y. (2022). On recurrent-event win ratio.
#' Statistical Methods in Medical Research, under review.
#' @references Pocock, S., Ariti, C., Collier, T., and Wang, D. (2012). The win ratio: a new approach
#' to the analysis of composite endpoints in clinical trials based on clinical priorities.
#'  European Heart Journal, 33, 176--182.
#'
#' @examples
#' ## load the HF-ACTION trial data
#' library(WR)
#' head(hfaction_cpx9)
#' dat <- hfaction_cpx9
#' ## Comparing exercise training to usual care by LWR, FWR, and NWR
#' obj <- WRrec(ID=dat$patid, time=dat$time, status=dat$status,
#'           trt=dat$trt_ab, strata=dat$age60, naive=TRUE)
#' ## print the results
#' obj
#'
#' @section Interpretation:
#' A win ratio greater than 1 favors subjects in group \code{trt == 1} (more wins than losses across
#' pairwise recurrent event trajectory comparisons). The log scale is used for
#' inference; confidence intervals can be constructed as
#' \code{exp(log.WR +/- z_{alpha/2} * se)}.
#'
#' @keywords WRrec
#' @export
#' @aliases WRrec
#' @seealso \code{\link{print.WRrec}}.
WRrec <- function(ID, time, status, trt, strata = NULL, naive = FALSE) {
  # Input validation
  n <- length(ID)

  # # Lengths
  if (
    n == 0L ||
      n != length(time) ||
      n != length(status) ||
      n != length(trt) ||
      (!is.null(strata) && n != length(strata))
  ) {
    stop(
      "ID, time, status, trt (and strata if provided) must have same, non-zero length"
    )
  }

  # Types
  if (!(typeof(time) %in% c("integer", "double"))) {
    stop("time must be numeric/integer")
  }
  if (!(typeof(status) %in% c("integer", "double"))) {
    stop("status must be numeric/integer")
  }
  if (!(typeof(trt) %in% c("integer", "double"))) {
    stop("trt must be numeric/integer")
  }
  if (!is.logical(naive) || length(naive) != 1L || is.na(naive)) {
    stop("naive must be a single logical: TRUE or FALSE")
  }
  if (!is.null(strata)) {
    if (is.factor(strata)) {
      strata <- as.integer(strata)
    } else if (!(typeof(strata) %in% c("integer", "double"))) {
      stop("strata must be numeric/integer or factor (or NULL)")
    }
  }

  # # NA checks
  if (
    anyNA(ID) ||
      anyNA(time) ||
      anyNA(status) ||
      anyNA(trt) ||
      (!is.null(strata) && anyNA(strata))
  ) {
    stop("ID/time/status/trt (and strata if provided) must not contain NA")
  }

  # # time >= 0
  if (min(time) < 0) {
    stop("time must be a non-negative numeric vector")
  }

  # # status in {0,1,2}
  us <- unique.default(status)
  if (length(us) > 3L || any(us < 0 | us > 2) || any(us != floor(us))) {
    stop(
      "status must be in {0 (censor), 1 (terminal), 2 (recurrent)} and integer-like"
    )
  }

  # # trt in {0,1}
  ut <- unique.default(trt)
  if (length(ut) > 2L || any(ut < 0 | ut > 1) || any(ut != floor(ut))) {
    stop("trt must be in {0,1} and integer-like")
  }

  # # At most one final (status 0 or 1) per subject
  idx <- which(status != 2L)
  if (length(idx) && anyDuplicated(ID[idx])) {
    stop("Each subject can have at most one final status of 0 or 1")
  }

  # # If strata is given, check that it does not change within id
  if (!is.null(strata)) {
    if (
      length(
        off <- names(which(tapply(strata, ID, \(x) length(unique(x)) > 1)))
      )
    ) {
      stop(
        "Invalid: 'strata' changes within id: ",
        paste(off, collapse = ", "),
        call. = FALSE
      )
    }
  }

  # Core code
  n_total <- as.numeric(length(unique(ID)))

  # ---- Descriptive ----
  n1 <- as.numeric(length(unique(ID[trt == 1])))
  n0 <- as.numeric(length(unique(ID[trt == 0])))
  Nrec1 <- as.numeric(sum(status[trt == 1] == 2))
  Nrec0 <- as.numeric(sum(status[trt == 0] == 2))
  Ndeath1 <- as.numeric(sum(status[trt == 1] == 1))
  Ndeath0 <- as.numeric(sum(status[trt == 0] == 1))
  X <- as.numeric(time[status != 2])
  MedFU1 <- as.numeric(median(X[trt[status != 2] == 1]))
  MedFU0 <- as.numeric(median(X[trt[status != 2] == 0]))

  desc <- rbind(
    c(n0, Nrec0, Ndeath0, MedFU0),
    c(n1, Nrec1, Ndeath1, MedFU1)
  )
  colnames(desc) <- c("N", "Rec. Event", "Death", "Med. Follow-up")
  rownames(desc) <- c("Control", "Treatment")

  # ---- Strata handling ----
  if (is.null(strata)) {
    strata <- rep(1, length(ID))
  }
  stratum.list <- unique(strata)
  K <- length(stratum.list)

  Theta <- matrix(NA_real_, nrow = 2L, ncol = K)
  Sigma <- matrix(0.0, 2L, 2L)

  # If naive=TRUE, prepare containers for NWR and FWR
  if (naive) {
    Theta_nwr <- matrix(NA_real_, 2L, K)
    Sigma_nwr <- matrix(0.0, 2L, 2L)
    Theta_fwr <- matrix(NA_real_, 2L, K)
    Sigma_fwr <- matrix(0.0, 2L, 2L)
  }

  weights <- numeric(K)

  for (k in seq_len(K)) {
    ind <- (strata == stratum.list[k])
    obj <- process.dat(ID[ind], time[ind], status[ind], trt[ind])
    dat1 <- obj$dat1
    dat0 <- obj$dat0

    weights[k] <- (length(dat1) + length(dat0)) / n_total

    # LWR
    wrobj_lwr <- wr_stat_se_rule_soa_cpp(dat1, dat0, rule = "lwr")
    Theta[, k] <- wrobj_lwr$theta
    Sigma <- Sigma + weights[k] * wrobj_lwr$Sigma

    if (naive) {
      # NWR
      wrobj_nwr <- wr_stat_se_rule_soa_cpp(dat1, dat0, rule = "nwr")
      Theta_nwr[, k] <- wrobj_nwr$theta
      Sigma_nwr <- Sigma_nwr + weights[k] * wrobj_nwr$Sigma

      # FWR
      wrobj_fwr <- wr_stat_se_rule_soa_cpp(dat1, dat0, rule = "fwr")
      Theta_fwr[, k] <- wrobj_fwr$theta
      Sigma_fwr <- Sigma_fwr + weights[k] * wrobj_fwr$Sigma
    }
  }

  # Combine strata
  theta <- rowSums(Theta * rbind(weights, weights))
  out <- list(theta = theta)

  if (any(theta <= 0)) {
    log.WR <- if (theta[1] > 0 && theta[2] > 0) {
      log(theta[1] / theta[2])
    } else {
      NA_real_
    }
    se <- NA_real_
    pval <- NA_real_
  } else {
    f <- c(1 / theta[1], -1 / theta[2])
    se <- as.numeric(sqrt(t(f) %*% Sigma %*% f / n_total))
    log.WR <- log(theta[1] / theta[2])
    z <- log.WR / se
    pval <- 2 * pnorm(-abs(z))
  }

  # Optional variants when naive=TRUE
  if (naive) {
    theta.naive <- rowSums(Theta_nwr * rbind(weights, weights))
    theta.FI <- rowSums(Theta_fwr * rbind(weights, weights))

    if (all(theta.naive > 0)) {
      fN <- c(1 / theta.naive[1], -1 / theta.naive[2])
      se.naive <- as.numeric(sqrt(t(fN) %*% Sigma_nwr %*% fN / n_total))
      log.WR.naive <- log(theta.naive[1] / theta.naive[2])
    } else {
      se.naive <- NA_real_
      log.WR.naive <- NA_real_
    }

    if (all(theta.FI > 0)) {
      fF <- c(1 / theta.FI[1], -1 / theta.FI[2])
      se.FI <- as.numeric(sqrt(t(fF) %*% Sigma_fwr %*% fF / n_total))
      log.WR.FI <- log(theta.FI[1] / theta.FI[2])
    } else {
      se.FI <- NA_real_
      log.WR.FI <- NA_real_
    }
  } else {
    theta.naive <- NULL
    se.naive <- NULL
    log.WR.naive <- NULL
    theta.FI <- NULL
    se.FI <- NULL
    log.WR.FI <- NULL
  }

  nb.pairs <- if (K == 1L) {
    as.numeric(n0) * as.numeric(n1)
  } else {
    sum(sapply(stratum.list, function(s) {
      ind <- (strata == s)
      as.numeric(length(unique(ID[ind & (trt == 0)]))) *
        as.numeric(length(unique(ID[ind & (trt == 1)])))
    }))
  }

  structure(
    list(
      log.WR = log.WR,
      se = se,
      pval = if (is.finite(se) && is.numeric(se)) {
        2 * pnorm(-abs(log.WR / se))
      } else {
        NA_real_
      },
      theta = theta,
      log.WR.naive = log.WR.naive,
      se.naive = se.naive,
      theta.naive = theta.naive,
      pval.naive = if (is.finite(se.naive) && is.numeric(se.naive)) {
        2 * pnorm(-abs(log.WR.naive / se.naive))
      } else {
        NA_real_
      },
      log.WR.FI = log.WR.FI,
      se.FI = se.FI,
      theta.FI = theta.FI,
      pval.FI = if (is.finite(se.FI) && is.numeric(se.FI)) {
        2 * pnorm(-abs(log.WR.FI / se.FI))
      } else {
        NA_real_
      },
      call = match.call(),
      nb.pairs = nb.pairs,
      desc = desc
    ),
    class = "WRrec"
  )
}
