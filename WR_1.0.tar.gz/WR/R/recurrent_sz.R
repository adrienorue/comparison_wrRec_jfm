# simple helper to avoid the same seed being used across different sample sizes
.seed_for <- function(baseSeed, n, i, block = 5e4L) {
    as.numeric(baseSeed + n * block + i)
}


# Validate arguments for recurrent event sample size simulations.
.validation_inputs <- function(params) {
    err <- function(msg) {
        stop(sprintf("[sz_lwr] %s", msg), call. = FALSE)
    }
    is_scal_num <- function(x) is.numeric(x) && length(x) == 1L && is.finite(x)
    is_whole_number <- function(x, tol = .Machine$double.eps^0.5) {
        is_scal_num(x) && abs(x - round(x)) <= tol
    }
    must_prob <- function(x, nm) {
        if (!is_scal_num(x) || x <= 0 || x >= 1) {
            err(sprintf("'%s' must be in (0, 1).", nm))
        }
    }
    must_pos <- function(x, nm) {
        if (!is_scal_num(x) || x <= 0) {
            err(sprintf("'%s' must be a positive finite number.", nm))
        }
    }
    must_nonneg <- function(x, nm) {
        if (!is_scal_num(x) || x < 0) err(sprintf("'%s' must be >= 0.", nm))
    }
    must_int <- function(x, nm) {
        if (!is_scal_num(x) || x != as.integer(x)) {
            err(sprintf("'%s' must be an integer.", nm))
        }
    }
    must_int_pos <- function(x, nm) {
        if (!is_scal_num(x) || x <= 0 || x != as.integer(x)) {
            err(sprintf("'%s' must be a positive integer.", nm))
        }
    }
    normalize_ni_inputs <- function(niType, ni) {
        if (missing(niType) || length(niType) == 0 || is.null(niType)) {
            err("'niType' must be specified.")
        }
        niType <- niType[[1L]]
        niType <- tolower(niType)
        niType <- tryCatch(
            match.arg(niType, c("max", "poisson", "unif")),
            error = function(e) {
                err("'niType' must be one of 'max', 'poisson', or 'unif'.")
            }
        )
        if (missing(ni) || is.null(ni)) {
            err("'ni' must be provided.")
        }
        if (!is.numeric(ni) || !length(ni)) {
            err("'ni' must be numeric.")
        }
        if (niType == "max") {
            if (length(ni) != 1L) {
                err("'ni' must be a single value when niType = 'max'.")
            }
            val <- ni[[1]]
            if (!is.finite(val)) {
                if (!is.infinite(val) || val < 0) {
                    err("'ni' must be positive or Inf when niType = 'max'.")
                }
            } else if (val < 0 || !is_whole_number(val)) {
                err(
                    "'ni' must be a non-negative integer or Inf when niType = 'max'."
                )
            }
            return(list(type = niType, value = val))
        }
        if (niType == "poisson") {
            if (length(ni) != 1L) {
                err("'ni' must be a single value when niType = 'poisson'.")
            }
            val <- ni[[1]]
            if (!is.finite(val) || val < 0) {
                err(
                    "'ni' must be a non-negative finite number when niType = 'poisson'."
                )
            }
            return(list(type = niType, value = val))
        }
        if (length(ni) != 2L) {
            err("'ni' must contain two values when niType = 'unif'.")
        }
        vals <- as.numeric(ni)
        if (any(!is.finite(vals))) {
            err("'ni' must be finite when niType = 'unif'.")
        }
        if (any(vals < 0) || any(!vapply(vals, is_whole_number, logical(1)))) {
            err("'ni' must contain non-negative integers when niType = 'unif'.")
        }
        lower <- min(vals)
        upper <- max(vals)
        if (upper < lower) {
            err("For niType = 'unif', the second value must be >= the first.")
        }
        list(type = niType, value = c(lower, upper))
    }

    if (is.null(params$baseSeed)) {
        params$baseSeed <- 0L
    } else if (!is_whole_number(params$baseSeed)) {
        err("'baseSeed' must be a single finite integer.")
    } else {
        params$baseSeed <- as.integer(params$baseSeed)
    }
    must_prob(params$target_power, "target_power")
    must_prob(params$type1_error, "type1_error")
    must_pos(params$recurrent_weibull_shape, "recurrent_weibull_shape")
    must_pos(params$recurrent_weibull_scale, "recurrent_weibull_scale")
    must_pos(params$terminal_weibull_shape, "terminal_weibull_shape")
    must_pos(params$terminal_weibull_scale, "terminal_weibull_scale")
    must_pos(params$HR_recurrent, "HR_recurrent")
    must_pos(params$HR_terminal, "HR_terminal")
    must_nonneg(params$theta, "theta")
    must_nonneg(params$alpha, "alpha")
    if (!is.null(params$censoring_rate)) {
        must_nonneg(params$censoring_rate, "censoring_rate")
    }
    must_pos(params$censoring_time, "censoring_time")

    if (is.null(params$fupType) || !length(params$fupType)) {
        err("'fupType' must be specified.")
    }
    fupType <- tolower(params$fupType[[1L]])
    fupType <- tryCatch(
        match.arg(fupType, c("fixed", "uptoend")),
        error = function(e) {
            err("'fupType' must be either 'fixed' or 'uptoend'.")
        }
    )
    params$fupType <- fupType
    must_nonneg(params$accrualDuration, "accrualDuration")

    must_int(params$sample_size_min, "sample_size_min")
    must_int(params$sample_size_max, "sample_size_max")
    must_int_pos(params$sample_size_step, "sample_size_step")
    if (params$sample_size_min < 2) {
        err("'sample_size_min' must be at least 2.")
    }
    if (params$sample_size_max < params$sample_size_min) {
        err("'sample_size_max' must be >= 'sample_size_min'.")
    }
    must_int_pos(params$n_sim, "n_sim")

    extra_args <- params$extra_generation_args
    if (length(extra_args)) {
        if (!is.null(extra_args$fixedCensor)) {
            warning(
                "`fixedCensor` supplied through ... is ignored; use `censoring_time` instead.",
                call. = FALSE
            )
            extra_args$fixedCensor <- NULL
        }
        protected <- c(
            "nSubjects",
            "betaGap",
            "betaDeathStar",
            "seed",
            "ni",
            "niType",
            "fixedCensor",
            "fupType",
            "accrualDuration"
        )
        protected <- protected[protected %in% names(extra_args)]
        if (length(protected)) {
            warning(
                sprintf(
                    "The following arguments supplied via ... are ignored: %s",
                    paste(protected, collapse = ", ")
                ),
                call. = FALSE
            )
            extra_args[protected] <- NULL
        }
    }

    params$sample_size_min <- as.integer(params$sample_size_min)
    params$sample_size_max <- as.integer(params$sample_size_max)
    params$sample_size_step <- as.integer(params$sample_size_step)
    params$n_sim <- as.integer(params$n_sim)
    params$extra_generation_args <- extra_args
    ni_parsed <- normalize_ni_inputs(params$niType, params$ni)
    params$niType <- ni_parsed$type
    params$ni <- ni_parsed$value
    params
}


# Build the grid of sample sizes to explore.
.build_sz_grid <- function(min_size, max_size, step_size) {
    grid <- seq.int(min_size, max_size, by = step_size)
    grid[grid >= 2L]
}


# Fit the LWR.
.fit_lwr <- function(longData, n_pairs = NULL) {
    # n1 <- length(unique(longData$id[longData$z1 == 1L]))
    # n0 <- length(unique(longData$id[longData$z1 == 0L]))
    # pairs <- as.numeric(n1) * as.numeric(n0)

    if (is.null(n_pairs)) {
        # fast count from longData without unique()
        first_row <- !duplicated(longData$id)
        z <- longData$z1[first_row]
        n1 <- sum(z == 1L)
        n0 <- length(z) - n1
        pairs <- n1 * n0
    } else {
        pairs <- n_pairs
    }

    res <- try(
        WRrec(
            ID = longData$id,
            time = longData$tStop,
            status = longData$status,
            trt = longData$z1,
            strata = NULL,
            naive = FALSE
        ),
        silent = TRUE
    )

    if (inherits(res, "try-error")) {
        return(list(pval = NA_real_, ties = NA_real_, pairs = pairs))
    }
    logWR <- as.numeric(res$log.WR)
    se <- as.numeric(res$se)
    pval <- as.numeric(res$pval)
    if (!is.finite(pval)) {
        z <- logWR / se
        pval <- if (is.finite(z)) 2 * stats::pnorm(-abs(z)) else NA_real_
    }
    theta <- as.numeric(res$theta)
    tie_prop <- if (all(is.finite(theta))) max(0, 1 - sum(theta)) else NA_real_
    ties_cnt <- if (is.finite(tie_prop)) round(pairs * tie_prop) else NA_real_
    list(pval = pval, ties = ties_cnt, pairs = pairs)
}


# Generate longitudinal data based on the inverse transform sampling method of a JFM.
.data_jfm <- function(
    nSubjects = 400,
    theta = 0.5, # gamma frailty variance (mean 1, var theta)
    alpha = 1, # exponent linking frailty to death hazard (PH only)
    fixedCensor = 3.0, # administrative censoring time (common horizon)
    fupType = c("fixed", "uptoend"),
    accrualDuration = 0,
    expCensor = NULL, # optional: additional exponential censoring rate
    betaGap = c(log(0.8), 0), # recurrence: (z1, z2) coefficients
    betaDeathStar = log(0.85), # death: z1 coefficient
    niType = c("max", "poisson", "unif"),
    ni = Inf,
    # Weibull params
    shapeRec = 1.3,
    scaleRec = 2.0,
    shapeDeath = 1.2,
    scaleDeath = 3.0,
    seed = 42
) {
    niType <- match.arg(niType, c("max", "poisson", "unif"))
    fupType <- match.arg(fupType, c("fixed", "uptoend"))

    ni_params <- if (niType == "max") {
        c(ni, NA_real_)
    } else if (niType == "poisson") {
        c(ni, NA_real_)
    } else {
        c(ni[1], ni[2])
    }

    out <- dataGen(
        nSubjects,
        theta,
        alpha,
        fixedCensor,
        as.numeric(betaGap),
        betaDeathStar,
        if (is.null(seed)) NA_integer_ else as.integer(seed),
        ni_type = switch(niType, max = 0L, poisson = 1L, unif = 2L),
        ni_param1 = ni_params[1],
        ni_param2 = if (!is.na(ni_params[2])) ni_params[2] else NA_real_,
        shapeRec,
        scaleRec,
        shapeDeath,
        scaleDeath,
        fup_type = switch(fupType, fixed = 0L, uptoend = 1L),
        accrual_duration = accrualDuration
    )

    .exponential_censoring <- function(longData, rate) {
        id <- longData$id
        time <- longData$time
        death <- longData$death
        rec <- longData$recurrence
        z1 <- longData$z1
        z2 <- longData$z2

        rl <- rle(id)
        ends <- cumsum(rl$lengths)
        starts <- c(1L, head(ends + 1L, -1L))
        m <- length(rl$lengths)

        Cin <- stats::rexp(m, rate = rate)

        out <- vector("list", m)

        for (k in seq_len(m)) {
            s <- starts[k]
            e <- ends[k]
            times <- time[s:e]
            tC <- Cin[k]
            last <- times[length(times)]

            if (tC >= last) {
                stat <- integer(length(times))
                stat[death[s:e] == 1L] <- 1L
                stat[rec[s:e] == 1L] <- 2L

                out[[k]] <- data.frame(
                    id = id[s:e],
                    time = times,
                    death = death[s:e],
                    recurrence = rec[s:e],
                    z1 = z1[s:e],
                    z2 = z2[s:e],
                    stringsAsFactors = FALSE
                )
            } else {
                keep <- sum(times < tC)
                if (keep > 0L) {
                    # rows strictly before tC
                    i1 <- s:(s + keep - 1L)
                    block <- data.frame(
                        id = id[i1],
                        time = times[seq_len(keep)],
                        death = death[i1],
                        recurrence = rec[i1],
                        z1 = z1[i1],
                        z2 = z2[i1],
                        stringsAsFactors = FALSE
                    )
                    # censoring row at tC
                    block <- rbind(
                        block,
                        data.frame(
                            id = id[s],
                            time = tC,
                            death = 0L,
                            recurrence = 0L,
                            z1 = z1[s],
                            z2 = z2[s],
                            stringsAsFactors = FALSE
                        )
                    )
                    out[[k]] <- block
                } else {
                    out[[k]] <- data.frame(
                        id = id[s],
                        time = tC,
                        death = 0L,
                        recurrence = 0L,
                        z1 = z1[s],
                        z2 = z2[s],
                        stringsAsFactors = FALSE
                    )
                }
            }
        }

        res <- do.call(rbind, out)
        rownames(res) <- NULL
        res
    }

    if (!is.null(expCensor) && is.finite(expCensor) && expCensor > 0) {
        out$longData <- .exponential_censoring(
            out$longData,
            expCensor
        )
    }

    longData <- as.data.frame(out$longData)
    longData <- longData[order(longData$id, longData$time), ]
    longData <- within(longData, {
        tStart <- ave(time, id, FUN = function(x) c(0, head(x, -1)))
        tStop <- time
        status <- ifelse(
            death == 0 & recurrence == 0,
            0L,
            ifelse(
                death == 1 & recurrence == 0,
                1L,
                ifelse(death == 0 & recurrence == 1, 2L, NA_integer_)
            )
        )
    })

    # keep only what's used for lwr
    longData <- longData[, c("id", "tStop", "status", "z1"), drop = FALSE]
    names(longData)[2] <- "tStop"

    list(longData = longData, subjectData = out$subjectData, truth = out$truth)
}


# Helper for .data_jfm
.generate_data <- function(
    n,
    HR_R,
    HR_D,
    sim_base_args,
    extra_generation_args,
    sim_id
) {
    args <- c(
        extra_generation_args,
        sim_base_args,
        list(
            nSubjects = n,
            betaGap = c(log(HR_R), 0),
            betaDeathStar = log(HR_D),
            seed = sim_id
        )
    )
    try(do.call(.data_jfm, args))
}


# Run Monte Carlo evaluation for a single scenario.
.single_mc_replicate <- function(
    n,
    HR_R,
    HR_D,
    n_sim,
    type1_error,
    seeds, # vector of per-replicate seeds
    sim_base_args,
    extra_generation_args,
    progress_cb = NULL
) {
    rejects <- logical(n_sim)
    ties <- rep(NA_real_, n_sim)

    for (i in seq_len(n_sim)) {
        sim_id <- seeds[i]
        set.seed(sim_id)
        sim <- .generate_data(
            n,
            HR_R,
            HR_D,
            sim_base_args,
            extra_generation_args,
            sim_id = sim_id
        )
        if (inherits(sim, "try-error") || is.null(sim$longData)) {
            rejects[i] <- FALSE
            ties[i] <- NA_real_
            if (!is.null(progress_cb)) {
                progress_cb()
            }
            next
        }

        pairs <- {
            z <- sim$subjectData$z1
            n1 <- sum(z == 1L)
            n0 <- length(z) - n1
            n1 * n0
        }

        longData <- sim$longData
        if (!is.data.frame(longData) || !nrow(longData)) {
            rejects[i] <- FALSE
            ties[i] <- NA_real_
            if (!is.null(progress_cb)) {
                progress_cb()
            }
            next
        }

        longData <- longData[
            is.finite(longData$tStop) & longData$tStop >= 0,
            ,
            drop = FALSE
        ]
        if (!nrow(longData)) {
            rejects[i] <- FALSE
            ties[i] <- NA_real_
            if (!is.null(progress_cb)) {
                progress_cb()
            }
            next
        }

        fit <- .fit_lwr(longData, n_pairs = pairs)

        if (!is.finite(fit$pval)) {
            rejects[i] <- FALSE
        } else {
            rejects[i] <- fit$pval < type1_error
        }
        ties[i] <- if (is.finite(fit$ties)) fit$ties else NA_real_

        if (!is.null(progress_cb)) progress_cb()
    }

    list(
        estimate = mean(rejects),
        ties_mean = mean(ties, na.rm = TRUE)
    )
}


.summarize_res <- function(
    n_grid,
    power_vec,
    t1e_vec,
    ties_vec,
    target_power,
    type1_error
) {
    summary_df <- data.frame(
        sample_size = n_grid,
        estimated_power = power_vec,
        estimated_type_I_error = t1e_vec,
        stringsAsFactors = FALSE
    )

    ok <- which(power_vec >= target_power & t1e_vec <= type1_error)
    n_star <- if (length(ok)) n_grid[min(ok)] else NA_integer_
    idx_star <- if (!is.na(n_star)) which(n_grid == n_star) else integer()
    achieved_power <- if (length(idx_star)) power_vec[idx_star] else NA_real_
    achieved_t1e <- if (length(idx_star)) t1e_vec[idx_star] else NA_real_
    expected_ties <- stats::setNames(ties_vec, as.character(n_grid))
    ties_at_n_star <- if (!is.na(n_star)) {
        expected_ties[[as.character(n_star)]]
    } else {
        NA_real_
    }

    list(
        summary_table = summary_df,
        computed_sample_size = n_star,
        achieved_power = achieved_power,
        achieved_type_I_error = achieved_t1e,
        expected_ties = expected_ties,
        ties_at_n_star = ties_at_n_star
    )
}


.plot_res <- function(
    summary_df,
    target_power,
    n_sim,
    theta,
    type1_error,
    censoring_time,
    n_star,
    output_plot_file
) {
    p <- ggplot(
        summary_df,
        aes(sample_size, estimated_power)
    ) +
        geom_line() +
        geom_point() +
        geom_hline(yintercept = target_power, linetype = "dashed") +
        labs(
            x = "Sample size",
            y = "Estimated power",
            title = sprintf("Power vs. sample size (%d simulations)", n_sim),
            subtitle = sprintf(
                "Gamma-frailty variance = %.3f; Type I error = %.3f; Admin. censoring = %.2f",
                theta,
                type1_error,
                censoring_time
            )
        ) +
        theme_minimal()

    if (!is.na(n_star)) {
        p <- p +
            geom_vline(
                xintercept = n_star,
                linetype = "dashed",
                color = "red"
            )
    }

    ggsave(
        filename = output_plot_file,
        plot = p,
        width = 7,
        height = 4.5,
        dpi = 300
    )
    p
}


#' Sample size computation for recurrent event using the last-event-assisted win ratio (LWR)
#'
#' @description This function performs Monte Carlo simulations under both the alternative and
#' null hypotheses to identify the smallest sample size achieving the desired
#' power while controlling the type I error of the win ratio procedure. The data generation is based
#' on a joint frailty model with Weibull baseline hazards for both recurrent and terminal events.
#' This allows, in particular, for taking into account the heterogeneity and association between
#' recurrent events and the terminal event.
#'
#' @param power Numeric value between 0 and 1, representing the desired power for the alternative scenario.
#' @param type1Error Numeric value between 0 and 1, representing the nominal type I error level for the LWR test.
#' @param HR_recurrent Positive value, corresponding to the hazard ratio for recurrent events under the alternative.
#' @param HR_terminal Positive value, corresponding to the hazard ratio for terminal events under the alternative.
#' @param weibShapeRec Positive value, corresponding to the Weibull shape for the recurrent baseline hazard.
#' @param weibScaleRec Positive value, corresponding to the Weibull scale for the recurrent baseline hazard.
#' @param weibShapeTerm Positive value, corresponding to the Weibull shape for the terminal event baseline hazard.
#' @param weibScaleTerm Positive value, corresponding to the Weibull scale for the terminal event baseline hazard.
#' @param niType Character string, describing the nature of the recurrent events. Options are:
#' \itemize{
#'     \item "max": Each subject can have up to \code{ni} recurrent events.
#'     \item "poisson": Each subject's maximum recurrent-event count is drawn from Poisson(\code{ni}).
#'     \item "unif": Each subject's maximum recurrent-event count is drawn uniformly between the values in \code{ni = c(lower, upper)}.
#' }
#' Defaults to \code{niType = "max"}.
#' @param ni Character string, that is associated with \code{niType}.
#' \itemize{
#'     \item If \code{niType} is "max", \code{ni} is the maximum number of recurrent events per subject.
#'     \item If \code{niType} is "poisson", \code{ni} is the mean of the Poisson distribution used to draw per-subject caps.
#'     \item If \code{niType} is "unif", \code{ni} is a 2D-vector corresponding to the minimum and maximum cap for each subject.
#' }
#' Defaults to \code{ni = Inf} (so that, with \code{niType = "max"}, we generate as many recurrent events per subject as possible).
#' @param theta Positive value, corresponding to the gamma frailty variance.
#' @param alpha Numeric value, controlling association between recurrent and terminal processes.
#' @param FUP Positive numeric value, corresponding to the follow-up duration (i.e. administrative censoring). Default is 3.
#' @param fupType Character string, indicating the follow-up scheme (case-insensitive). Options are:
#' \itemize{
#'     \item \code{"fixed"}: each subject is followed exactly for \code{FUP} time units after enrollment.
#'     \item \code{"uptoend"}: global study cutoff at time \code{FUP}; individual follow-up for at most \code{FUP} depending on their accrual time.
#' }
#' Default is \code{"fixed"}.
#' @param accrualDuration Non-negative numeric value describing a uniform accrual window from time 0 to \code{accrualDuration}. Only
#' meaningful when \code{fupType = "uptoend"}. Defaults to 0 (no "accrual").
#' @param expoCensoringRate Optional positive value, that corresponds to the Exponential parameter (i.e., rate).
#' If provided, an additional independent exponential censoring is added to the administrative censoring. Defaults to \code{NULL}.
#' @param sample_size_min Minimum sample size checked. Defaults to 400.
#' @param sample_size_max Maximum sample size checked. Defaults to 2000.
#' @param sample_size_step Step size for the sample size grid. Defaults to 200.
#' @param n_sim Number of Monte Carlo replications per scenario. Defaults to 500.
#' @param baseSeed Integer base seed for random number generation. Defaults to 42.
#' @param output_plot_file File path where the power curve is saved.
#' @param ... Additional arguments passed to the data generation function \code{data_jfm()}.
#' @return
#' A list with the following components:
#' \describe{
#'     \item{\code{summary_table}}{Data frame summarizing the estimated power and type I error across sample sizes.}
#'     \item{\code{computed_sample_size}}{Sample size achieving the desired power while controlling type I error (if any found).}
#'     \item{\code{achieved_power}}{Estimated power at the recommended sample size (if any found).}
#'     \item{\code{achieved_type_I_error}}{Estimated type I error at the recommended sample size (if any found).}
#'     \item{\code{expected_ties}}{Named vector of expected tie counts at each sample size.}
#'     \item{\code{ties_at_n_star}}{Expected tie count at the recommended sample size (if any found).}
#'     \item{\code{power_curve_plot}}{ggplot2 object representing the power curve across sample sizes.}
#'     \item{\code{output_plot_file}}{File path where the power curve was saved.}
#' }
#'
#' @details Under the null, both HR (rec. and terminal) are set to 1.0.
#'
#' The Weibull parametrization is: \eqn{h_0(t) = \frac{shape}{scale} \left(\frac{t}{scale}\right)^{shape - 1}}.
#' If one want to generate data with an exponential baseline risk, put shape = 1 and scale = 1 / lambda,
#' where lambda is the rate (parameter of the exponential distribution).
#'
#' We recall that a gamma-joint frailty model includes a common frailty term to the
#' individuals \eqn{(\omega_i)} for the two rates which will take into account
#' the heterogeneity in the data, associated with unobserved covariates. The
#' frailty term acts differently for the two rates (\eqn{\omega_i} for the
#' recurrent rate and \eqn{\omega_i^{\alpha}} for the death rate). The
#' covariates could be different for the recurrent rate and death rate.
#' For the \eqn{j^{th}} recurrence \eqn{(j=1,...,n_i)} and the
#' \eqn{i^{th}} subject \eqn{(i=1,...,N)}, the joint gamma frailty model
#' for recurrent event hazard function \eqn{r_{ij}(.)} and death rate
#' \eqn{\lambda_i(.)} is:
#'
#' \deqn{\left\{
#' \begin{array}{ll}
#' r_{ij}(t|\omega_i)=\omega_ir_0(t)\exp(\bold{\beta_1^{'}Z_i(t)}) & \mbox{(Recurrent)} \\
#' \lambda_i(t|\omega_i)=\omega_i^{\alpha}\lambda_0(t)\exp(\bold{\beta_2^{'}Z_i(t)}) & \mbox{(Death)}
#' \end{array}
#' \right.}
#'
#' where \eqn{r_0(t)} (resp. \eqn{\lambda_0(t)}) is the recurrent (resp.
#' terminal) event baseline hazard function, \eqn{\bold{\beta_1}} (resp.
#' \eqn{\bold{\beta_2}}) the regression coefficient vector, \eqn{\bold{Z_i(t)}}
#' the covariate vector. The random effects of frailties
#' \eqn{\omega_i\sim\bold{\Gamma}(\frac{1}{\theta},\frac{1}{\theta})}, are
#' iid, with mean 1 and variance \eqn{\theta}. The parameter \eqn{\alpha}
#' quantifies the strength (and direction) of association between the recurrent event process
#' and the terminal event.
#'
#' @references Mao, L., Kim, K. and Li, Y. (2022). On recurrent-event win ratio.
#' Statistical Methods in Medical Research, under review.
#' @references Pocock, S., Ariti, C., Collier, T., and Wang, D. (2012). The win ratio: a new approach
#' to the analysis of composite endpoints in clinical trials based on clinical priorities.
#'  European Heart Journal, 33, 176--182.
#' @references V. Rondeau, S. Mathoulin-Pellissier, H. Jacqmin-Gadda, V. Brouste, P.
#' Soubeyran (2007). Joint frailty models for recurring events and death using
#' maximum penalized likelihood estimation:application on cancer events.
#' \emph{Biostatistics} \bold{8},4, 708-721.
#'
#' @examples
#' \dontrun{
#' res <- sz_lwr(
#'     power = 0.80,
#'     type1Error = 0.05,
#'     weibShapeRec = 1,
#'     weibScaleRec = (3.6 / 12) / log(2),
#'     weibShapeTerm = 1,
#'     weibScaleTerm = (28 / 12) / log(2),
#'     HR_recurrent = 0.80,
#'     HR_terminal = 0.90,
#'     niType = "poisson",
#'     ni = 3,
#'     theta = 1.0,
#'     alpha = 1.0,
#'     fupType = "uptoend",
#'     FUP = 4,
#'     accrualDuration = 3,
#'     sample_size_min = 400,
#'     sample_size_max = 2000,
#'     sample_size_step = 200,
#'     n_sim = 500,
#'     baseSeed = 42,
#'     output_plot_file = sprintf(
#'         "power_curve_%s.png",
#'         gsub("[ :\\-]", "_", round(Sys.time(), 0))
#'     )
#' )
#' }
#'
#' @import ggplot2
#' @export

sz_lwr <- function(
    power,
    type1Error,
    HR_recurrent,
    HR_terminal,
    weibShapeRec,
    weibScaleRec,
    weibShapeTerm,
    weibScaleTerm,
    niType = "max",
    ni = Inf,
    theta,
    alpha,
    expoCensoringRate = NULL,
    FUP = 3,
    fupType = "fixed",
    accrualDuration = 0,
    sample_size_min = 400,
    sample_size_max = 2000,
    sample_size_step = 200,
    n_sim = 500,
    baseSeed = 42,
    output_plot_file = sprintf(
        "power_curve_%s.png",
        gsub("[ :\\-]", "_", round(Sys.time(), 0))
    ),
    ...
) {
    niType <- match.arg(niType, c("max", "poisson", "unif"))
    fupType <- match.arg(fupType, c("fixed", "uptoend"))
    extra_generation_args <- list(...)
    params <- list(
        target_power = power,
        type1_error = type1Error,
        HR_recurrent = HR_recurrent,
        HR_terminal = HR_terminal,
        recurrent_weibull_shape = weibShapeRec,
        recurrent_weibull_scale = weibScaleRec,
        terminal_weibull_shape = weibShapeTerm,
        terminal_weibull_scale = weibScaleTerm,
        niType = niType,
        ni = ni,
        theta = theta,
        alpha = alpha,
        censoring_rate = expoCensoringRate,
        censoring_time = FUP,
        fupType = fupType,
        accrualDuration = accrualDuration,
        sample_size_min = sample_size_min,
        sample_size_max = sample_size_max,
        sample_size_step = sample_size_step,
        n_sim = n_sim,
        output_plot_file = output_plot_file,
        baseSeed = baseSeed,
        extra_generation_args = extra_generation_args
    )
    validated <- .validation_inputs(params)

    n_grid <- .build_sz_grid(
        validated$sample_size_min,
        validated$sample_size_max,
        validated$sample_size_step
    )

    power_vec <- numeric(length(n_grid))
    t1e_vec <- numeric(length(n_grid))
    ties_vec <- numeric(length(n_grid))

    total_steps <- length(n_grid) * validated$n_sim * 2L
    pb <- utils::txtProgressBar(
        min = 0,
        max = if (total_steps > 0) total_steps else 1,
        style = 3
    )
    progress_counter <- 0L
    on.exit(close(pb), add = TRUE)
    progress_tick <- function() {
        progress_counter <<- progress_counter + 1L
        utils::setTxtProgressBar(pb, progress_counter)
    }

    sim_base_args <- list(
        theta = validated$theta,
        alpha = validated$alpha,
        shapeRec = validated$recurrent_weibull_shape,
        scaleRec = validated$recurrent_weibull_scale,
        shapeDeath = validated$terminal_weibull_shape,
        scaleDeath = validated$terminal_weibull_scale,
        niType = validated$niType,
        ni = validated$ni,
        fixedCensor = validated$censoring_time,
        fupType = validated$fupType,
        accrualDuration = validated$accrualDuration
    )

    for (j in seq_along(n_grid)) {
        n <- n_grid[j]

        seeds_n <- vapply(
            seq_len(validated$n_sim),
            function(i) .seed_for(validated$baseSeed, n, i),
            numeric(1)
        )

        alt_res <- .single_mc_replicate(
            n = n,
            HR_R = validated$HR_recurrent,
            HR_D = validated$HR_terminal,
            n_sim = validated$n_sim,
            type1_error = validated$type1_error,
            seeds = seeds_n,
            sim_base_args = sim_base_args,
            extra_generation_args = validated$extra_generation_args,
            progress_cb = progress_tick
        )
        power_vec[j] <- if (is.finite(alt_res$estimate)) alt_res$estimate else 0

        nul_res <- .single_mc_replicate(
            n = n,
            HR_R = 1.0,
            HR_D = 1.0,
            n_sim = validated$n_sim,
            type1_error = validated$type1_error,
            seeds = seeds_n,
            sim_base_args = sim_base_args,
            extra_generation_args = validated$extra_generation_args,
            progress_cb = progress_tick
        )
        t1e_vec[j] <- if (is.finite(nul_res$estimate)) nul_res$estimate else 1
        ties_vec[j] <- if (is.finite(alt_res$ties_mean)) {
            alt_res$ties_mean
        } else {
            NA_real_
        }
    }

    summary <- .summarize_res(
        n_grid = n_grid,
        power_vec = power_vec,
        t1e_vec = t1e_vec,
        ties_vec = ties_vec,
        target_power = validated$target_power,
        type1_error = validated$type1_error
    )

    plot_obj <- .plot_res(
        summary_df = summary$summary_table,
        target_power = validated$target_power,
        n_sim = validated$n_sim,
        theta = validated$theta,
        type1_error = validated$type1_error,
        censoring_time = validated$censoring_time,
        n_star = summary$computed_sample_size,
        output_plot_file = validated$output_plot_file
    )

    if (is.na(summary$computed_sample_size)) {
        warning(
            "No sample size in the examined range achieved both the target power and type I error."
        )
    }

    list(
        computed_sample_size = summary$computed_sample_size,
        achieved_power = summary$achieved_power,
        achieved_type_I_error = summary$achieved_type_I_error,
        summary_table = summary$summary_table,
        expected_ties = summary$expected_ties,
        ties_at_n_star = summary$ties_at_n_star,
        power_curve_plot = plot_obj,
        output_plot_file = validated$output_plot_file
    )
}
