// Purpose: Structure-of-Arrays (SoA) implementation from the previous Array-of-Structures (AoS) version.
// Notes: - Assumes per-subject time vectors are sorted ascending (=> process.dat()).
//        - Designed to work with (terrifyingly) large cohorts; uses contiguous buffers and
//          precomputed scalars to minimize pointer chasing and allocation.

// [[Rcpp::depends(Rcpp)]]
#include <Rcpp.h>
#include <limits>
using namespace Rcpp;

#if defined(_MSC_VER)
#define RESTRICT __restrict
#else
#define RESTRICT __restrict__
#endif

// Small branch prediction hints
#if defined(__GNUC__) || defined(__clang__)
#define LIKELY(x) __builtin_expect(!!(x), 1)
#define UNLIKELY(x) __builtin_expect(!!(x), 0)
#else
#define LIKELY(x) (x)
#define UNLIKELY(x) (x)
#endif

// ----------------------- Change of datastructure -----------------------
struct SoAArm
{
  std::vector<double> times; // concatenated time stamps for all subjects
  std::vector<int> off;      // start offset into `times` for subject k
  std::vector<int> len;      // number of time points for subject k
  std::vector<int> status;
  std::vector<double> max_t;
  std::vector<double> first_t;
  int n = 0;

  static SoAArm from_R_list(const Rcpp::List &dat)
  {
    SoAArm A;
    const int n = dat.size();
    A.n = n;
    A.off.resize(n);
    A.len.resize(n);
    A.status.resize(n);
    A.max_t.resize(n);
    A.first_t.resize(n);

    // Compute total size for times vector
    size_t total = 0;
    for (int k = 0; k < n; ++k)
    {
      const Rcpp::List s = dat[k];
      const Rcpp::NumericVector tk = s["time"];
      total += static_cast<size_t>(tk.size());
    }
    A.times.resize(total);

    // Fill in the times vector
    size_t cursor = 0;
    for (int k = 0; k < n; ++k)
    {
      const Rcpp::List s = dat[k];
      const Rcpp::NumericVector tk = s["time"];
      const int lk = static_cast<int>(tk.size());
      A.off[k] = static_cast<int>(cursor);
      A.len[k] = lk;
      A.status[k] = Rcpp::as<int>(s["status"]);
      if (lk > 0)
      {
        A.first_t[k] = tk[0];
        A.max_t[k] = tk[lk - 1];
        std::copy(tk.begin(), tk.end(), A.times.begin() + cursor);
      }
      else
      {
        A.first_t[k] = std::numeric_limits<double>::quiet_NaN();
        A.max_t[k] = std::numeric_limits<double>::quiet_NaN();
      }
      cursor += static_cast<size_t>(lk);
    }
    return A;
  }
};

// ---------- helpers  ----------

// Linear scan that count and return entries <= X in sorted array (ascending).
inline int count_leq_ptr(const double *RESTRICT p, int n, double X)
{
  int k = 0;
  for (; k < n; ++k)
  {
    if (p[k] <= X)
      continue;
    break;
  }
  return k;
}

inline int count_recurrences_upto(const SoAArm &A, int i, double X, bool truncated)
{
  const double *RESTRICT p = A.times.data() + A.off[i];
  const int li = A.len[i];
  // # of observations at or before X
  int cnt = count_leq_ptr(p, li, X);

  // If NOT truncated and X == max_t[i] and last status is non-recurrence (0=censor, 1=death),
  // subtract that terminal row from the recurrence count.
  if (!truncated && A.max_t[i] <= X && A.status[i] != 2 && cnt > 0)
  {
    cnt -= 1;
  }
  return cnt; // # recurrent events at/before X
}

inline bool died_by_X(const SoAArm &A, int i, bool truncated)
{
  // A subject can only die "by X" if they are NOT truncated and last status==1
  return (!truncated) && (A.status[i] == 1);
}

inline double first_event_time_upto(const SoAArm &A, int i)
{
  // assumes at least one recurrence exists by X
  return A.times[A.off[i]];
}

inline double last_event_time_upto(const SoAArm &A, int i, int k, double X, bool truncated)
{
  // k >= 1 recurrence count by X
  if (truncated)
  {
    // truncation guarantees all counted events <= X; last is at index off + (k-1)
    return A.times[A.off[i] + (k - 1)];
  }
  else
  {
    // X == max_t[i]; if last status was non-recurrence we subtracted it already,
    // so last recurrence is at index off + (k-1)
    return A.times[A.off[i] + (k - 1)];
  }
}

// ---------- NWR: death priority; break tie by counts ----------
inline int compare_NWR_pair_soa(const SoAArm &A, int i, const SoAArm &B, int j)
{
  const double Xi = A.max_t[i], Xj = B.max_t[j];
  const bool trunci = (Xi > Xj);
  const bool truncj = (Xj > Xi);
  const double X = trunci ? Xj : Xi;

  // 1/ Death priority on [0, X]
  const bool di = (!trunci) && (A.status[i] == 1); // death by X for i
  const bool dj = (!truncj) && (B.status[j] == 1); // death by X for j
  if (di != dj)
    return dj ? +1 : -1; // the one who died loses

  // 2/ Both alive at X -> compare recurrence counts
  const int ki = count_recurrences_upto(A, i, X, trunci);
  const int kj = count_recurrences_upto(B, j, X, truncj);
  if (ki != kj)
    return (kj > ki) ? +1 : -1; // more events -> loses

  // 3/ Tie
  return 0;
}

// ---------- LWR: death priority; counts; if equal and >=1, tie-break by T_[last-1] ----------
inline int compare_LWR_pair_soa(const SoAArm &A, int i, const SoAArm &B, int j)
{
  const double Xi = A.max_t[i], Xj = B.max_t[j];
  const double X = Xi < Xj ? Xi : Xj;
  const bool trunci = (Xi > X); // i has longer follow-up than X -> truncated at X
  const bool truncj = (Xj > X);

  // 1/ Death priority on [0, X]
  const bool di = (!trunci) && (A.status[i] == 1); // death by X for i
  const bool dj = (!truncj) && (B.status[j] == 1); // death by X for j
  if (di != dj)
    return dj ? +1 : -1; // the one who died loses

  // 2/ Both alive at X -> compare recurrence counts
  const int ki = count_recurrences_upto(A, i, X, trunci);
  const int kj = count_recurrences_upto(B, j, X, truncj);
  if (ki != kj)
    return (kj > ki) ? +1 : -1; // more events -> loses

  // 3/ If tie and >=1, compare last event times on [0, X]
  if (ki == 0 && kj == 0)
    return 0;
  const double ti_last = last_event_time_upto(A, i, ki, X, trunci);
  const double tj_last = last_event_time_upto(B, j, kj, X, truncj);
  if (tj_last < ti_last)
    return +1; // earlier last event loses
  if (ti_last < tj_last)
    return -1;

  // 4/ Tie
  return 0;
}

// ---------- FWR: death priority; counts; if equal and >=1, tie-break by T1 ----------
inline int compare_FWR_pair_soa(const SoAArm &A, int i, const SoAArm &B, int j)
{
  const double Xi = A.max_t[i], Xj = B.max_t[j];
  const bool trunci = (Xi > Xj);
  const bool truncj = (Xj > Xi);
  const double X = trunci ? Xj : Xi;

  // 1/ Death priority on [0, X]
  const bool di = (!trunci) && (A.status[i] == 1);
  const bool dj = (!truncj) && (B.status[j] == 1);
  if (di != dj)
    return dj ? +1 : -1;

  // 2/ Both alive at X -> compare recurrence counts
  const int ki = count_recurrences_upto(A, i, X, trunci);
  const int kj = count_recurrences_upto(B, j, X, truncj);
  if (ki != kj)
    return (kj > ki) ? +1 : -1; // more events -> loses

  // 3/ If tie and counts >=1, compare first event times on [0, X]
  if (ki == 0 && kj == 0)
    return 0;
  const double ti_first = first_event_time_upto(A, i);
  const double tj_first = first_event_time_upto(B, j);
  if (tj_first < ti_first)
    return +1; // earlier first event loses
  if (ti_first < tj_first)
    return -1;

  // 4/ Tie
  return 0;
}

namespace
{

  inline NumericMatrix cov_center_2x2(const std::vector<int> &a1,
                                      const std::vector<int> &a2,
                                      double scale1, double scale2,
                                      double mu1, double mu2)
  {
    const int n = static_cast<int>(a1.size());
    NumericMatrix S(2, 2);
    if (n <= 1)
      return S;
    double c11 = 0.0, c22 = 0.0, c12 = 0.0;
    for (int k = 0; k < n; ++k)
    {
      const double x1 = a1[k] * scale1 - mu1;
      const double x2 = a2[k] * scale2 - mu2;
      c11 += x1 * x1;
      c22 += x2 * x2;
      c12 += x1 * x2;
    }
    const double inv = 1.0 / static_cast<double>(n - 1);
    S(0, 0) = c11 * inv;
    S(0, 1) = c12 * inv;
    S(1, 0) = c12 * inv;
    S(1, 1) = c22 * inv;
    return S;
  }

  struct WRCoreResult
  {
    NumericVector theta;
    NumericMatrix Sigma;
    double dn1;
    double dn0;
    double denom;
    double ntot;
  };

  template <typename Comparator>
  WRCoreResult compute_wr_core(const SoAArm &A, const SoAArm &B, Comparator cmp)
  {
    const int n1 = A.n;
    const int n0 = B.n;

    std::vector<int> wins_i(n1, 0), losses_i(n1, 0);
    std::vector<int> wins_j(n0, 0), losses_j(n0, 0);

    long long sum_wins_i = 0;
    long long sum_losses_i = 0;

    for (int j = 0; j < n0; ++j)
    {
      int wj = 0, lj = 0;
      for (int i = 0; i < n1; ++i)
      {
        const int r = cmp(i, j);
        if (LIKELY(r != INT_MIN) && r != 0)
        {
          if (r > 0)
          {
            ++wins_i[i];
            ++lj;
          }
          else
          {
            ++losses_i[i];
            ++wj;
          }
        }
      }
      wins_j[j] = wj;
      losses_j[j] = lj;
      sum_losses_i += wj;
      sum_wins_i += lj;
    }

    const double dn1 = static_cast<double>(n1);
    const double dn0 = static_cast<double>(n0);
    const double denom = dn1 * dn0;

    NumericVector theta(2);
    theta[0] = static_cast<double>(sum_wins_i) / denom;
    theta[1] = static_cast<double>(sum_losses_i) / denom;

    NumericMatrix S_i = cov_center_2x2(wins_i, losses_i,
                                       1.0 / dn0, 1.0 / dn0,
                                       theta[0], theta[1]);
    NumericMatrix S_j = cov_center_2x2(losses_j, wins_j,
                                       1.0 / dn1, 1.0 / dn1,
                                       theta[0], theta[1]);

    const double ntot = dn1 + dn0;
    const double fac_i = ntot * (dn1 - 1.0) / (dn1 * dn1);
    const double fac_j = ntot * (dn0 - 1.0) / (dn0 * dn0);

    NumericMatrix Sigma(2, 2);
    Sigma(0, 0) = fac_i * S_i(0, 0) + fac_j * S_j(0, 0);
    Sigma(0, 1) = fac_i * S_i(0, 1) + fac_j * S_j(0, 1);
    Sigma(1, 0) = Sigma(0, 1);
    Sigma(1, 1) = fac_i * S_i(1, 1) + fac_j * S_j(1, 1);

    return WRCoreResult{theta, Sigma, dn1, dn0, denom, ntot};
  }

} // namespace

// [[Rcpp::export]]
Rcpp::List wr_stat_se_rule_soa_cpp(Rcpp::List dat1, Rcpp::List dat0, std::string rule)
{
  SoAArm A = SoAArm::from_R_list(dat1); // treated
  SoAArm B = SoAArm::from_R_list(dat0); // control
  const int n1 = A.n, n0 = B.n;

  if (n1 == 0 || n0 == 0)
    Rcpp::stop("Both arms must contain at least one subject.");

  enum class Rule
  {
    LWR,
    NWR,
    FWR
  };
  Rule R;
  if (rule == "lwr")
    R = Rule::LWR;
  else if (rule == "nwr")
    R = Rule::NWR;
  else if (rule == "fwr")
    R = Rule::FWR;
  else
    Rcpp::stop("Unknown rule: use 'lwr', 'nwr', or 'fwr'.");

  WRCoreResult core = [&]() -> WRCoreResult
  {
    if (R == Rule::LWR)
    {
      return compute_wr_core(A, B, [&](int i, int j)
                             { return compare_LWR_pair_soa(A, i, B, j); });
    }
    if (R == Rule::NWR)
    {
      return compute_wr_core(A, B, [&](int i, int j)
                             { return compare_NWR_pair_soa(A, i, B, j); });
    }
    return compute_wr_core(A, B, [&](int i, int j)
                           { return compare_FWR_pair_soa(A, i, B, j); });
  }();

  return Rcpp::List::create(_["theta"] = core.theta, _["Sigma"] = core.Sigma);
}
