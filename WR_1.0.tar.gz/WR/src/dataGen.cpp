// [[Rcpp::plugins(cpp11)]]
#include <Rcpp.h>
#include <cmath>
#include <algorithm>
#include <limits>

using namespace Rcpp;

enum NiType
{
  NI_MAX = 0,
  NI_POISSON = 1,
  NI_UNIF = 2
};

enum FUPType
{
  FUP_FIXED = 0,
  FUP_UPTOEND = 1
};

// Various helpers and data prep

inline double runif01() { return R::runif(0.0, 1.0); }
inline double pos(double x) { return (x > 1e-12) ? x : 1e-12; }

/*  Proportional hazards samplers */
inline double sample_exp(double rate0, double accel)
{
  double u = runif01();
  return -std::log(u) / pos(rate0 * accel);
}
/*
Prameterization (see wikipedia): shape = k, scale = lambda, accel = exp(beta'X)
- Baseline S0(t) = exp(-(t/lambda)^k)
- Hence, S(t|accel) = exp(- accel * (t/lambda)^k)  =>  t = lambda * [ -log(U) / accel ]^{1/k}
*/
inline double sample_weibull(double scale, double shape, double accel)
{
  double u = runif01();
  return scale * std::pow(-std::log(u) / pos(accel), 1.0 / shape);
}

void apply_seed(Nullable<int> seed)
{
  if (seed.isNotNull())
  {
    Environment base("package:base");
    Function set_seed = base["set.seed"];
    set_seed(as<int>(seed));
  }
}

/* Collects validated inputs for the data genereation */
struct SimulationConfig
{
  int nSubjects;
  double theta;
  double alpha;
  double censoring_time;
  double betaGap1;
  double betaGap2;
  double betaDeathStar;
  NiType niType;
  double niParam1;
  double niParam2;
  double shapeRec;
  double scaleRec;
  double shapeDeath;
  double scaleDeath;
  FUPType fupType;
  double accDur;
};

/* Validates and retype raw inputs */
SimulationConfig make_config(
    int nSubjects,
    double theta,
    double alpha,
    double fixedCensor,
    const NumericVector &betaGap,
    double betaDeathStar,
    double shapeRec,
    double scaleRec,
    double shapeDeath,
    double scaleDeath,
    int ni_type,
    double ni_param1,
    double ni_param2,
    int fup_type,
    double accrual_duration)
{
  if (betaGap.size() < 2)
  {
    stop("betaGap must have length >= 2 (z1, z2).");
  }

  const NiType niType = static_cast<NiType>(ni_type);
  const FUPType ftype = static_cast<FUPType>(fup_type);

  return SimulationConfig{
      nSubjects,
      theta,
      alpha,
      fixedCensor,
      betaGap[0],
      betaGap[1],
      betaDeathStar,
      niType,
      ni_param1,
      ni_param2,
      shapeRec,
      scaleRec,
      shapeDeath,
      scaleDeath,
      ftype,
      accrual_duration};
}

/* Individual subject attributes. */
struct SubjectAttributes
{
  double frailty;
  int z1;
  int z2;
};

/* Linear predictor for rec. and term. events. */
struct SubjectEffects
{
  double frailty;
  int z1;
  int z2;
  double etaRec;
  double etaDeath;
};

/* Builds the subject attributes from the raw vectors. */
SubjectAttributes make_subject_attributes(
    const NumericVector &frailty,
    const NumericVector &z1,
    const NumericVector &z2,
    int index)
{
  return SubjectAttributes{
      frailty[index],
      static_cast<int>(z1[index]),
      static_cast<int>(z2[index])};
}

/* Combines covariate and frailty information into model-specific effects. */
SubjectEffects compute_subject_effects(
    const SimulationConfig &config,
    const SubjectAttributes &subject)
{
  const double etaRec = config.betaGap1 * subject.z1 + config.betaGap2 * subject.z2;
  const double etaDeath = config.betaDeathStar * subject.z1;
  return SubjectEffects{subject.frailty, subject.z1, subject.z2, etaRec, etaDeath};
}

double draw_death_time(const SimulationConfig &config, const SubjectEffects &subject)
{
  const double accelD = std::pow(subject.frailty, config.alpha) * std::exp(subject.etaDeath);
  return sample_weibull(config.scaleDeath, config.shapeDeath, accelD);
}

double draw_recurrence_gap(const SimulationConfig &config, const SubjectEffects &subject)
{
  const double accelR = subject.frailty * std::exp(subject.etaRec);
  return sample_weibull(config.scaleRec, config.shapeRec, accelR);
}

/* Draws the per-subject max nb. of rec. events (depends on niType) */
int draw_max_recurrences(const SimulationConfig &config)
{
  const int int_max = std::numeric_limits<int>::max();
  if (config.niType == NI_MAX)
  {
    if (!R_finite(config.niParam1))
    {
      return int_max;
    }
    const double bounded = std::floor(std::max(0.0, config.niParam1));
    if (bounded >= static_cast<double>(int_max))
    {
      return int_max;
    }
    return static_cast<int>(bounded);
  }
  if (config.niType == NI_POISSON)
  {
    const double lambda = std::max(0.0, config.niParam1);
    const double draw = R::rpois(lambda);
    if (draw >= static_cast<double>(int_max))
    {
      return int_max;
    }
    return static_cast<int>(draw);
  }
  int lower = static_cast<int>(std::llround(config.niParam1));
  int upper = static_cast<int>(std::llround(config.niParam2));
  if (upper < lower)
  {
    std::swap(lower, upper);
  }
  if (lower < 0)
  {
    lower = 0;
  }
  if (upper < lower)
  {
    upper = lower;
  }
  if (upper == lower)
  {
    return lower;
  }
  const int range = upper - lower + 1;
  const double u = runif01();
  int draw = lower + static_cast<int>(std::floor(u * range));
  if (draw > upper)
  {
    draw = upper;
  }
  return draw;
}

// Main
// [[Rcpp::export]]
List dataGen(
    int nSubjects,
    double theta,
    double alpha,
    double fixedCensor,
    NumericVector betaGap, // (z1, z2) for recurrence
    double betaDeathStar,  // z1 for death
    Nullable<int> seed,
    double shapeRec, double scaleRec,
    double shapeDeath, double scaleDeath,
    int ni_type,
    double ni_param1,
    double ni_param2,
    int fup_type,
    double accrual_duration)
{
  apply_seed(seed);
  RNGScope rngScope;

  const SimulationConfig config = make_config(
      nSubjects,
      theta,
      alpha,
      fixedCensor,
      betaGap,
      betaDeathStar,
      shapeRec,
      scaleRec,
      shapeDeath,
      scaleDeath,
      ni_type,
      ni_param1,
      ni_param2,
      fup_type,
      accrual_duration);

  // 1) Subject-level draws
  NumericVector frailty = rgamma(config.nSubjects, 1.0 / config.theta, config.theta); // mean=1, var=theta
  NumericVector z1 = rbinom(config.nSubjects, 1, 0.5);
  NumericVector z2 = rbinom(config.nSubjects, 1, 0.5); // NOT USED

  // 2) Allocate long data buffers
  std::vector<int> id;
  std::vector<double> time;
  std::vector<int> recurrence;
  std::vector<int> death;
  std::vector<int> z1Long;
  std::vector<int> z2Long;

  id.reserve(8 * nSubjects); // 4 betteR?
  time.reserve(8 * nSubjects);
  recurrence.reserve(8 * nSubjects);
  death.reserve(8 * nSubjects);
  z1Long.reserve(8 * nSubjects);
  z2Long.reserve(8 * nSubjects);

  // Subject-level summaries
  NumericVector eventEndTime(config.nSubjects);
  IntegerVector died(config.nSubjects);
  NumericVector censorTime(config.nSubjects, config.censoring_time);
  NumericVector accrual(config.nSubjects);
  NumericVector calendarEndTime(config.nSubjects);

  // 3) Simulate per subject
  for (int i = 0; i < config.nSubjects; ++i)
  {
    const SubjectAttributes subjectAttr = make_subject_attributes(frailty, z1, z2, i);
    const SubjectEffects subjectEffects = compute_subject_effects(config, subjectAttr);

    // --- Subject-specific accrual & admin censoring
    double accr = 0.0;
    if (config.fupType == FUP_UPTOEND)
    {
      accr = R::runif(0.0, std::max(0.0, config.accDur));
    }
    accrual[i] = accr;

    double adminCensor = config.censoring_time;
    if (config.fupType == FUP_UPTOEND)
    {
      // Up to global cutoff at Acc.Dur + FUP: subject max follow-up (on subject time) is Acc.Dur + FUP - accrual
      adminCensor = std::max(0.0, config.accDur + config.censoring_time - accr);
    }
    censorTime[i] = adminCensor;

    const double deathTime = draw_death_time(config, subjectEffects);
    const double stopTime = std::min(adminCensor, deathTime);
    eventEndTime[i] = stopTime;
    died[i] = static_cast<int>(deathTime < adminCensor);
    calendarEndTime[i] = accr + stopTime;

    // Generate rec. gaptimes until stopTime or reached cap
    const int maxRecur = std::max(0, draw_max_recurrences(config));
    int recCount = 0;
    double t = 0.0;
    while (true)
    {
      if (recCount >= maxRecur)
      {
        id.push_back(i + 1);
        time.push_back(stopTime);
        recurrence.push_back(0);
        death.push_back(died[i]);
        z1Long.push_back(subjectEffects.z1);
        z2Long.push_back(subjectEffects.z2);
        break;
      }

      double tnext = t + draw_recurrence_gap(config, subjectEffects);
      if (tnext < stopTime)
      {
        id.push_back(i + 1);
        time.push_back(tnext);
        recurrence.push_back(1);
        death.push_back(0);
        z1Long.push_back(subjectEffects.z1);
        z2Long.push_back(subjectEffects.z2);
        t = tnext;
        recCount++;
      }
      else
      {
        id.push_back(i + 1);
        time.push_back(stopTime);
        recurrence.push_back(0);
        death.push_back(died[i]);
        z1Long.push_back(subjectEffects.z1);
        z2Long.push_back(subjectEffects.z2);
        break;
      }
    }
  }

  // 4) Return
  return List::create(
      _["longData"] = DataFrame::create(
          _["id"] = wrap(id),
          _["time"] = wrap(time),
          _["recurrence"] = wrap(recurrence),
          _["death"] = wrap(death),
          _["z1"] = wrap(z1Long),
          _["z2"] = wrap(z2Long)),
      _["subjectData"] = DataFrame::create(
          _["id"] = seq_len(nSubjects),
          _["omega"] = frailty,
          _["z1"] = as<IntegerVector>(z1),
          _["z2"] = as<IntegerVector>(z2),
          _["accrual"] = accrual,
          _["censorTime"] = censorTime,
          _["eventEndTime"] = eventEndTime,
          _["calendarEndTime"] = calendarEndTime,
          _["died"] = died),
      _["truth"] = List::create(
          _["beta1"] = betaGap[0],
          _["beta2"] = betaGap[1],
          _["betaStar"] = betaDeathStar,
          _["alpha"] = alpha,
          _["theta"] = theta,
          _["shapeRec"] = shapeRec,
          _["scaleRec"] = scaleRec,
          _["shapeDeath"] = shapeDeath,
          _["scaleDeath"] = scaleDeath,
          _["censoring_time"] = config.censoring_time,
          _["fup_type"] = fup_type,
          _["accDur"] = accrual_duration));
}
